                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:908046
Mobile Phone Selfie Adapter by don3sch is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

UPDATE: I ended up buying a selfie stick for $12 and recycled the extension pole into a fold-able backscratcher, which is getting used all the time!  Now included here.


Original post below this.

This idea should work with most 3d printable phone cases on Thingiverse.  All you need is the adapter from this project to connect between a printed phone case and the extension handle of the GO PRO balance thing below.  

I needed it to work with Samsung galaxy S4 Otterbox, so I included a modified file for that.  EDIT, this didn't work like I hoped so I made a generic phone caddy to hold a wider variety of phones.  

I Modified http://www.thingiverse.com/thing:319654 so that it doesn't need supports, laying this piece on its back shaved over 2 hours off the print time.  This use of the clip doesn't require the strength of normal use and wrapping a rubber band around the phone and printed case is an option if needed.   

FOR ALL OTHER PHONES:  
Get a case for your phone and the unmodified handle and extension section from http://www.thingiverse.com/thing:433378   

Included customized bolt and nut from NUT JOB (for testing), but ended up using M5 x 30mm for final assembly.  

BONUS for Samsung users:  Taking the selfie picture when camera is out of reach.  There is a mode on Galaxy S3 and S4 where you simply say "CHEESE" and it will take your picture, no Bluetooth, no button to push.  Other vendors may have a similar feature.  

UPDATE: June 4th, 2016  I added  a backscratcher attachment that works with this same go pro stick and adaptor.




# Instructions

I printed the extension sections (qty 3) at 50% for strong connectors, but the design is good and I'd do 30% if had it to do over.  

Printed handle from thing A and replacement Otterbox from thing B at 20%,  

Printed test nuts and bolts at 40%, They fit nice, but this project really needs metal bolts.