                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1930447
myTrackIR Clip  by Carlitros is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

I designed this TrackIR clip to use with my computer games.

I tried to accomplish it with the KISS principle, so design is simple and no assembling is required. One single piece, no glue, no screws...

It has been designed for SFH485P infrared leds, and you will also need a 10 to 20 ohm resistor and an USB cable (i used an old broken mouse to "steal" from).

Leds are inserted from the top with a gentle "click" and wires has enough room on the hollow arms. I made a curly canal for USB cable exit to avoid breaking it accidentally.

It should be printed with bottom on top, sorry, i will reupload conveniently rotated.

I mark this design as non-comercial, and no-derivatives. Contact me for that purpose, please.

# Print Settings

Printer Brand: RepRap
Printer: Prusa Mendel Iiteration 2
Rafts: No
Supports: No
Resolution: 0.1 mm
Infill: 100%

Notes: 
Printed with PLA i've got a good result, but i think it will be better using ABS.