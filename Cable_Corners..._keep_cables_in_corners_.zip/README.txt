                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1182945
Cable Corners... keep cables in corners! by muzz64 is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

If you're after a solution to keep the cables in your home or office close in to walls and corners this may be the answer. 'Cable Corners' keep your cables in corners and the straight section link cables along walls to keep them tucked away. No screws / nails / sticky tape required. Just form the cables into the required shape, push them in and  you're done...

These are all quick and easy prints of practical things that help keep cables tidy and safely secured out of harms way. The .stl's provided include files to accept 1 / 2 / 3 / 4 standard size power, HDMI, network or HDMI cables. Just form the cable to the shape required (90 degree corner) then push them down into the slots. Once in place the cable/s will settle into its new shape and stay in that position. 

Unlike the wind on cable conduit that requires cables to be wound in and don't conform to tight 90 degree corners, Cable Corners (and Straights) , make it quick and easy to insert and remove cables.   . 

Cable corners work with almost all common cable sizes up to 7.25mm diameter. If your cables/s are oversize just scale the print up to suit.  

This is a simple solution to an everyday issue in many office and homes.... tidy up your cables today!

Please refer to the images and print settings for additional information. 

Note: If you like this check out all my other practical and fun designs.  

# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator (5th Generation)
Rafts: Yes
Supports: No
Resolution: 0.20mm / Standard
Infill: 3 Shells / 35% or more...

Notes: 
Cable Corners need to be strong to retain the cables securely and hold their shape. For this reason use 3 shells and 35% infill or more... easy prints that don't use a lot of filament.