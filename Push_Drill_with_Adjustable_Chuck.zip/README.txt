                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:792988
Push Drill with Adjustable Chuck by LoboCNC is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Inspired by Speedy777's Pump Drill (http://www.thingiverse.com/thing:731086, which was inspired by Performance 3D's drill), this slightly beefier version features an adjustable chuck that can handle bits from 5mm (3/16") down to 1.5mm (1/16").  The end of the bit seats in the conical shaped chuck cavity, and the flexy fingers at the tip grab further up the shank.  You get 2 full rotations per stroke for fast drilling.  It also works as a pin vise for holding needle files.

# Instructions

Update: I've uploaded a new version of end_nub.STL which should fit better.  

All parts were printed in PLA with 3 perimeters and 30% infill.  The drill body was printed on end with 0.2mm layers - you may need a brim.  The slider, chuck and end nub were printed with 0.16mm layers.  The difference in layer height keeps the layer-line ridges from lining up with those on the drill body and makes for smoother operation.  Note that the chuck threads may need a little cleaning up with a triangular file.  

To assemble, first push the slider onto the body.  Next, put a little dab of grease on the end nub pin and click it onto the end of the drill body.  It should spin freely.  Finally, put a little bit of grease on the chuck threads and also on the outside of the tips of the flexy fingers and then screw on the chuck.  

To use, insert your bit (1.5 to 5mm) into the chuck until the end of the bit hits the bottom of the conical chuck cavity.  Then tighten the chuck just enough so you can't rotate the bit with your fingers.  Do not over-tighten - the flexy fingers will break!  This drill works best with very light downward pressure and a little patience.  (Tip: to drill larger holes, start by drilling a smaller pilot hole.)