                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2621901
Hexagon key handle by uvens is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

12-08-2018
I now release my improved model 2.0 of Allen Key Holder. It has better stability and does not release from the holder when pressed. Currently in four sizes. Personally, I like the new model better. The keys have a tight fit so you have to push them or use heat. I printed PLA with 0.2 resolution and 60% fill, no support needed. Enjoy!
The new STL-files are named hkeyX_x.stl
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -- - - - - - - -
Handle for hexagon key gives better grip. Sizes 4 mm, 3 mm, 2.5 mm, 2 mm and 1.5 mm.
01182018 - Changed number "3" on allen key 3. ;-)

# Print Settings

Printer Brand: Wanhao
Printer: Wanhao Duplicator i3 Plus
Rafts: No
Supports: No
Resolution: 0.4
Infill: 30%

Notes: 
Bed temp. 60, Extruder temp 220 C, 100% cooling from start. Paper glue on glass bed. Sliced with Simplify3D.

# Post-Printing

<iframe src="//www.youtube.com/embed/UpB8BnlYzCs" frameborder="0" allowfullscreen></iframe>

# How I Designed This

Used 123D Design